library(ggplot2)

# Generate Data 1 (rmethod = varying)
dat2 <- bkmr::SimData(n = 150, M = 2, sigsq.true = 0.5, beta.true = 2, hfun = 2, Zgen = 'norm',
                      ind = 1:2, family = 'gaussian')

y <- dat2$y; n <- length(y)
Z <- dat2$Z; M <- ncol(Z)
X <- dat2$X; p <- ncol(X)
true.h <- dat2$h

# fit the BKMR
(bkmr.time <- system.time({
  fout.bkmr <- bkmr::kmbayes(y = y, Z = Z, X = X, iter = 10000, rmethod = 'varying', varsel = FALSE, verbose = FALSE)
})[3])
summary(fout.bkmr)
bkmr.h <- bkmr::ComputePostmeanHnew(fout.bkmr)$postmean


# fit the vbayesGP meanfield
priors <- list(lengthscale='indep.normal', asig=0.001, bsig=0.001, alam=10, blam=1, tau0=10)
control <- list(rho=0.95, eps=1.0e-6, nws=2500, nsp=100, max_iter=100000)
(mvb.time <- system.time({
  fout.diag <- vbayesGP::gvagpr(y, X, Z, priors = priors, control = control, covstr = 'diagonal')
})[3])
summary(fout.diag)
mvb.h <- fitted(fout.diag)$fmean


# fit the vbayesGP full rank
(fvb.time <- system.time({
  fout.full <- vbayesGP::gvagpr(y, X, Z, priors = priors, control = control, covstr = 'fullrank')
})[3])
summary(fout.full)
fvb.h <- fitted(fout.full)$fmean


#### Minibatch (uniform)
# fit the vbayesGP meanfield
(mvbmbu.time <- system.time({
  foutmbu.diag <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'diagonal', minibatch = TRUE)
})[3])
summary(foutmbu.diag)
mvbmb.h <- fitted(foutmbu.diag)$fmean


# fit the vbayesGP full rank
(fvbmbu.time <- system.time({
  foutmbu.full <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'fullrank', minibatch = TRUE)
})[3])
summary(foutmbu.full)
fvbmb.h <- fitted(foutmbu.full)$fmean


