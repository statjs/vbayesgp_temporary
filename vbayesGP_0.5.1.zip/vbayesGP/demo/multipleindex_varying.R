library(ggplot2)

# Generate Data 1 (rmethod = varying)
data("nhanes", package = 'vbayesGP')
nhanes <- na.omit(nhanes)

set.seed(0)
n <- 500
nhanes <- nhanes[sample(nrow(nhanes))[1:n],]
doLog <- FALSE         ## dont log transform the exposures
source("NHANES_cleandat.R")

set.seed(1000) ## different outcomes/errors for each dataset
resample_ids <- 1:n  ## same exposures each iteration
dat <- prep_data_split(resample_ids)

# define exposure components
x1 <- X[,1:8]; x2 <- X[,9:10]; x3 <- X[,11:18]

# make true weight function
w1 <- c(8:1);     w1 <- w1/sqrt(sum(w1^2))
w2 <- c(-1,1);    w2 <- w2/sqrt(sum(w2^2))
w3 <- rep(-2,8);  w3 <- w3/sqrt(sum(w3^2))

# exposure reponse
wx1 <- x1%*%w1
wx2 <- x2%*%w2
wx3 <- x3%*%w3

## exposure response functions
h1fun <- function(z) dnorm(z-0.2,0,0.5) #(0.85*z)^2-0.5 # h1 <- 3/(1+exp(-2*wx1))
h2fun <- function(z) 0
h3fun <- function(z) 1/(1+exp(-5*z)) #1.5/(1+exp(-15*z)) -0.25*z

hfun <- function(z1,z2,z3){
  hh <- h1fun(z1)+h2fun(z2)+h3fun(z3)+0.5*h1fun(z1)*h3fun(z3)
  return(hh)
}
h <- hfun(wx1,wx2,wx3)

## covariate effects
gamma <- c(-0.43,0.00,-0.25,0.12,0.08)

## generate outcomes for entire dataset
sd <- 0.8
y <- h + covariates%*%gamma + rnorm(nrow(nhanes),0,1)*sd

# fit the BMIM
R <- 100000            ## no. of iterations
burn <- 0.5            ## percent burn-in
thin <- 10             ## thinning number
jump <- 0.35           ## sd of random walk for theta* bsmim
sel <- seq(burn*R+1,R,by=thin)

(bmim.time <- system.time({
  fout.bmim <- bsmim2::bsmim2(y=y, x=list(x1,x2,x3), z=covariates, niter=R, nburn=R*burn, nthin=thin, prior_sigma=c(0.001,0.001), prior_lambda_shaperate=c(1,0.1),
                              gaussian=TRUE,spike_slab=FALSE,gauss_prior=TRUE,stepsize_theta=jump,basis.opts=NULL,draw_h=FALSE, centering = FALSE, scaling = FALSE)
}))
lapply(fout.bmim$theta, colMeans)
colMeans(fout.bmim$rho)
colMeans(fout.bmim$gamma)
mean(fout.bmim$sigma2)
mean(1/fout.bmim$lambdaInverse)
hout <- bsmim2::predict_hnew_X2(fout.bmim, newX=dat$bsmim$X, newY=y, newZ=covariates)
hfit <- hout$fits$mean


# fit the vbayesGP meanfield
priors <- list(lengthscale='normal', asig=0.001, bsig=0.001, alam=1, blam=0.1, tau0=10)
control <- list(rho=0.95, eps=1.0e-6, nws=2500, nsp=200, max_iter=500000)
(mvb.time <- system.time({
  fout.diag <- vbayesGP::gvagpmim(y=y, X=covariates, Z=list(x1,x2,x3), priors = priors, control = control, covstr = 'diagonal')
})[3])
summary(fout.diag)
mvb.h <- fitted(fout.diag)$fmean


# fit the vbayesGP full rank
(fvb.time <- system.time({
  fout.full <- vbayesGP::gvagpmim(y=y, X=covariates, Z=list(x1,x2,x3), priors = priors, control = control, covstr = 'fullrank')
})[3])
summary(fout.full)
fvb.h <- fitted(fout.full)$fmean


#### Minibatch (uniform)
# fit the vbayesGP meanfield
(mvbmbu.time <- system.time({
  foutmbu.diag <- vbayesGP::gvagpmim(y=y, X=covariates, Z=list(x1,x2,x3), priors = priors, covstr = 'diagonal', minibatch = TRUE)
})[3])
summary(foutmbu.diag)
mvbmb.h <- fitted(foutmbu.diag)$fmean


# fit the vbayesGP full rank
(fvbmbu.time <- system.time({
  foutmbu.full <- vbayesGP::gvagpmim(y=y, X=covariates, Z=list(x1,x2,x3), priors = priors, covstr = 'fullrank', minibatch = TRUE)
})[3])
summary(foutmbu.full)
fvbmb.h <- fitted(foutmbu.full)$fmean


